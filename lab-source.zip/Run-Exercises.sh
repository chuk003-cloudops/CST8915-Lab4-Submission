#!/usr/bin/env bash
set -euo pipefail
cd ~/cst8915-lab4
echo 'PART 2: Docker fundamentals'
docker info
docker ps
docker ps -a
docker images
docker pull nginx:latest
docker run -d -p 80:80 --name my-nginx nginx:latest
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
docker logs my-nginx
docker exec my-nginx bash -c 'nginx -v; ls /usr/share/nginx/html'
docker stop my-nginx
docker start my-nginx
docker stop my-nginx
docker rm my-nginx
docker rmi nginx:latest
echo 'PART 3: Build and run Flask'
cd docker-lab
docker build --progress=plain -t my-python-app:v1 .
docker images
docker run -d -p 80:5000 --name python-app my-python-app:v1
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
curl -fsS http://localhost/health
docker inspect python-app
echo 'PART 4: Layers and caching'
docker history my-python-app:v1
docker inspect my-python-app:v1
docker build --progress=plain -t my-python-app:v2 .
sed -i 's/Hello from Docker!/Hello from Docker v2!/' app.py
docker build --progress=plain -t my-python-app:v3 .
echo 'PART 5: Separate writable layers and copy-on-write'
for n in 1 2 3; do
  docker run -d -p "$((5000+n)):5000" --name "app$n" my-python-app:v3
  docker exec "app$n" sh -c "echo 'Data in container $n' > /app/data$n.txt"
done
for n in 1 2 3; do
  echo "app$n files:"; docker exec "app$n" ls /app
  for other in 1 2 3; do
    if [ "$n" != "$other" ]; then docker exec "app$n" test ! -e "/app/data$other.txt"; fi
  done
done
docker ps -s
docker exec app1 sh -c "echo 'Modified app' >> /app/app.py"
docker exec app1 cat /app/app.py
docker exec app2 cat /app/app.py
docker exec app1 grep -q 'Modified app' /app/app.py
docker exec app2 sh -c "! grep -q 'Modified app' /app/app.py"
docker diff app1
docker stop python-app app1 app2 app3
docker rm python-app app1 app2 app3
echo 'PART 6: Flask + Redis Docker Compose'
cd ../docker-compose-lab
docker compose config --quiet
docker compose up -d --build
docker compose ps
for n in 1 2 3; do curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/; done
docker compose logs
docker compose logs web
docker compose logs redis
docker compose exec -T web sh -c 'hostname; ls /app'
docker compose stop
docker compose start
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
docker compose restart
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
docker compose down
docker compose up -d
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
docker compose down -v
docker compose up -d
curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
docker compose down
docker compose -f compose.scale.yml up -d --scale web=3
docker compose -f compose.scale.yml ps
for n in 1 2 3; do
  mapped=$(docker compose -f compose.scale.yml port --index "$n" web 5000 | head -1)
  port=${mapped##*:}
  curl --retry 10 --retry-all-errors --retry-delay 1 -fsS "http://127.0.0.1:$port/"
done
docker compose -f compose.scale.yml down
docker compose up -d
echo 'EXERCISES FINISHED; final Compose stack left running for genuine recording'
docker compose ps
