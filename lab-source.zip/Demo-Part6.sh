#!/usr/bin/env bash
set -euo pipefail
cd /home/azureuser/cst8915-lab4/docker-compose-lab
show() { clear; printf 'CST8915 Lab 4 | Part 6 | Chukwudubem Chukwurah | 041285726\n\n%s\n\n' "$1"; }
run() { printf '\n$ %s\n' "$*"; "$@"; }
show 'Flask + Redis: two services, a bridge network, and a named Redis volume'
run cat docker-compose.yml
sleep 7
run docker compose up -d
run docker compose ps
sleep 6
show 'Three HTTP visits share one Redis hit counter'
run curl -fsS http://localhost/
sleep 2
run curl -fsS http://localhost/
sleep 2
run curl -fsS http://localhost/
sleep 5
show 'Inspect the real web and Redis service logs'
run docker compose logs --tail=5 web
run docker compose logs --tail=5 redis
sleep 7
show 'Stop and start: containers retain their state'
run docker compose stop
run docker compose start
sleep 2
run curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
sleep 5
show 'Restart both services and execute a command inside the web container'
run docker compose restart
sleep 2
run curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
run docker compose exec -T web sh -c 'hostname; ls /app'
sleep 5
show 'Down removes containers and network, but preserves the Redis volume'
run docker compose down
run docker volume ls
run docker compose up -d
sleep 2
run curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
sleep 5
show 'Dynamic host ports allow three web instances to share Redis'
run docker compose down
run docker compose -f compose.scale.yml up -d --scale web=3
run docker compose -f compose.scale.yml ps
sleep 3
for n in 1 2 3; do
  mapped=$(docker compose -f compose.scale.yml port --index "$n" web 5000 | head -1)
  port=${mapped##*:}
  run curl --retry 10 --retry-all-errors --retry-delay 1 -fsS "http://127.0.0.1:$port/"
  sleep 2
done
sleep 5
show 'Down -v also removes the named volume: the counter resets to 1'
run docker compose -f compose.scale.yml down -v
run docker compose up -d
sleep 2
run curl --retry 10 --retry-all-errors --retry-delay 1 -fsS http://localhost/
sleep 5
show 'Part 6 complete: working Flask + Redis, persistence, scaling, and volume removal'
run docker compose ps
sleep 5
