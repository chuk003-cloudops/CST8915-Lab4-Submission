from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def hello():
    return f"Hello from Docker! Container ID: {os.uname().nodename}\n"

@app.route('/health')
def health():
    return "OK\n"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
